package mapreduce

//
// any additional state that you want to add to type WorkerInfo
//
type WorkerInfoImpl struct {
}

//
// run the MapReduce job across all the workers
//
func (mr *MapReduce) RunMasterImpl() {
}
